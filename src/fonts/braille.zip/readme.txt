         *************************************************
         *  These fonts  are  FREEWARE for PERSONNAL USE *
         *************************************************

It is requested, however, that you neither modify them, nor change
their names.
You can distribute them to whomever you like, insofar as this file
"README.TXT " accompanies them.
To make these fonts, I used a software bought in the USA, and thus
I HAVE the LICENCE OF USE.
These fonts works perfectly well under WINDOWS 95,98,2000 and up
as well as on my own computer.
Anyway, I could not be held responsible for any possible problems
that could derive from their use.

If you would like me to make a font of your personal handwriting
or any particular symbolic font, you just need to visit my
" PRICE " webpage here:

                    http://philing.net 

you will find all details.

                      To contact me:

   Philippe BLONDEL            phone: 336 512 486 05
    "Le Village"   
  32350  ORDAN-LARROQUE           Email : philing@hotmail.fr
     - FRANCE -                URL   : http://philing.net 


                   Your Handwriting Font !...
            The Best Way to Humanize Your Computer !...


*****************************************************************